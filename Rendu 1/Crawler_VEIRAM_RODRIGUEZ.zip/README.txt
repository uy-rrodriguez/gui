Bonjour Monsieur,

Excusez-nous pour le retard dans le rendu. Vous verrez dans le code qu'il y a quelques d�tails qui n'ont pas �t� r�solus. � savoir :
- Les images et vid�os sont t�l�charg�es en mode binaire mais on n'arrive pas � les ouvrir. Il doit avoir un probl�me dans le t�l�chargement.
- Dans Windows, la partie de visualisation ne fonctionne pas.
- Dans l'arbre de fichiers, on n'a pas ajout� les options pour les supprimer � cause de la manque de temps.
- Si on compile les sources et on les lance par console ou dans Eclipse, il n'y a pas de probl�me. N�anmoins, quand on lance l'application depuis le JAR, il ne trouve pas le fichier frxml.

Nous pourrions tout de m�me r�soudre les probl�mes qui restent et refaire le rendu � une autre date.


Parsing de pages :
- En ce qui concerne le parsing des HTML, nous avons utilis� la biblioth�que JSOAP, qui simplifie �normement le traitement des HTML et surtout le nettoyage du code avant tout traitement. Les JAR sont inclus dans les fichiers rendus.


Cordialement,

Marie Veiram
Ricardo Rodr�guez.